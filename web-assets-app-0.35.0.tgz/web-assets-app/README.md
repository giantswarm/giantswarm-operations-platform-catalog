# web-assets-app

Static files used on potentially multiple web sites

**Homepage:** <https://github.com/giantswarm/web-assets>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| name | string | `"web-assets-app"` |  |
| namespace | string | `"giantswarmio"` |  |
| image.registry | string | `"gsoci.azurecr.io"` |  |
| image.name | string | `"giantswarm/web-assets"` |  |
| resources.requests.cpu | string | `"5m"` |  |
| resources.requests.memory | string | `"5Mi"` |  |
| resources.requests.ephemeralStorage | string | `"50Mi"` |  |
| resources.limits.cpu | string | `"100m"` |  |
| resources.limits.memory | string | `"30Mi"` |  |
| resources.limits.ephemeralStorage | string | `"200Mi"` |  |
| route | object | `{"additionalRules":[],"annotations":{},"enabled":false,"filters":[],"hostnames":[],"kind":"HTTPRoute","labels":{},"matches":[{"path":{"type":"PathPrefix","value":"/"}}],"name":"","parentRefs":[],"securityPolicy":{"annotations":{},"enabled":false,"labels":{}}}` | Gateway API Route configuration |
| route.enabled | bool | `false` | Enable Gateway API HTTPRoute |
| route.kind | string | `"HTTPRoute"` | Set the route kind Valid options are GRPCRoute, HTTPRoute, TCPRoute, TLSRoute, UDPRoute |
| route.name | string | `""` | Override the route name (defaults to .Values.name) |
| route.annotations | object | `{}` | Additional annotations to add to the route |
| route.labels | object | `{}` | Additional labels to add to the route |
| route.hostnames | list | `[]` | Hostnames for the route |
| route.parentRefs | list | `[]` | Parent references (Gateway) for the route |
| route.matches | list | `[{"path":{"type":"PathPrefix","value":"/"}}]` | Matching rules for the route |
| route.filters | list | `[]` | Filters to apply to requests matching this rule |
| route.additionalRules | list | `[]` | Additional custom rules that can be added to the route |
| route.securityPolicy | object | `{"annotations":{},"enabled":false,"labels":{}}` | Envoy Gateway SecurityPolicy configuration |
| route.securityPolicy.enabled | bool | `false` | Enable SecurityPolicy for the route |
| route.securityPolicy.annotations | object | `{}` | Additional annotations for SecurityPolicy |
| route.securityPolicy.labels | object | `{}` | Additional labels for SecurityPolicy |
