# backstage

Backstage app provided by Giant Swarm

**Homepage:** <https://github.com/giantswarm/backstage>

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| oci://registry-1.docker.io/bitnamicharts | common | 2.41.0 |

## Architecture support

The `giantswarm/backstage` and `giantswarm/postgresql-cnpg` images are published
for `linux/amd64` and `linux/arm64` as manifest lists, so the chart runs on a
cluster with either architecture, or a mix of both.

Pin an image by the digest of the manifest list, never by the digest of one
architecture's manifest. A per-architecture digest defeats platform resolution:
the kubelet pulls that architecture on every node and the container exits with
`exec format error` on the others. Read the index digest with:

```
skopeo inspect --format '{{.Digest}}' docker://gsoci.azurecr.io/giantswarm/postgresql-cnpg:18.0
```

To steer placement, use `nodeSelector` for the Backstage pod and
`database.postgresql.affinity` for the PostgreSQL instance pods.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| name | string | `"backstage"` | Name used for all Kubernetes resources (Deployment, Service, Ingress, etc.) |
| replicas | int | `1` | Number of Backstage backend replicas |
| backstageDiscovery | object | `{"kubernetesId":"backstage"}` | Backstage service discovery settings |
| backstageDiscovery.kubernetesId | string | `"backstage"` | Value to set for the backstage.io/kubernetes-id label on all resources, used for entity discovery in Backstage |
| userID | int | `1000` | User ID for the pod security context (runAsUser) |
| groupID | int | `1000` | Group ID for the pod security context (runAsGroup) |
| fsGroupID | string | `nil` | Group ID for the pod security context (fsGroup). When set, Kubernetes chowns mounted volume roots to this GID on mount, so the non-root Backstage process can write to freshly provisioned PVCs (e.g. file-backed SQLite). Leave unset if no volumes need writing. |
| image | object | `{"name":"backstage","repository":"giantswarm/backstage"}` | Container image settings |
| image.name | string | `"backstage"` | Container name in the pod spec |
| image.repository | string | `"giantswarm/backstage"` | Image repository path (prepended with registry.domain to form the full image reference) |
| port | int | `7007` | Container port for the Backstage backend, also used for the Service and Ingress backend |
| probes | object | `{"liveness":{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":15,"timeoutSeconds":5},"readiness":{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"timeoutSeconds":5}}` | Liveness and readiness probe timing for the Backstage container. The HTTP path/port are fixed (`/.backstage/health/v1/{liveness,readiness}` on `port`); only the timing fields are tunable. `timeoutSeconds` defaults to 5 (k8s default is 1) because the Backstage backend can take >1s to answer the health endpoint under CPU pressure (CPU limit is 500m by default and event-loop stalls during plugin startup, GC, or DB reconnects produce `context deadline exceeded` warnings with the k8s default). |
| probes.liveness | object | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":15,"timeoutSeconds":5}` | Liveness probe timing |
| probes.liveness.initialDelaySeconds | int | `10` | Seconds after the container starts before the first liveness probe is performed |
| probes.liveness.periodSeconds | int | `15` | How often (in seconds) to perform the liveness probe |
| probes.liveness.timeoutSeconds | int | `5` | Number of seconds after which the liveness probe times out |
| probes.liveness.failureThreshold | int | `3` | Consecutive failures required to mark the container Unhealthy |
| probes.readiness | object | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"timeoutSeconds":5}` | Readiness probe timing |
| probes.readiness.initialDelaySeconds | int | `5` | Seconds after the container starts before the first readiness probe is performed |
| probes.readiness.periodSeconds | int | `10` | How often (in seconds) to perform the readiness probe |
| probes.readiness.timeoutSeconds | int | `5` | Number of seconds after which the readiness probe times out |
| probes.readiness.failureThreshold | int | `3` | Consecutive failures required to mark the container NotReady |
| registry | object | `{"domain":"gsoci.azurecr.io"}` | Container image registry settings |
| registry.domain | string | `"gsoci.azurecr.io"` | Container image registry domain prepended to image.repository |
| resources | object | `{"limits":{"cpu":"500m","memory":"600Mi"},"requests":{"cpu":"20m","memory":"250Mi"},"verticalPodAutoscaler":{"enabled":true}}` | Resource requests, limits, and autoscaler settings for the Backstage container |
| resources.verticalPodAutoscaler | object | `{"enabled":true}` | Vertical Pod Autoscaler settings |
| resources.verticalPodAutoscaler.enabled | bool | `true` | Enable the VerticalPodAutoscaler resource for automatic resource adjustment |
| resources.requests | object | `{"cpu":"20m","memory":"250Mi"}` | CPU and memory resource requests |
| resources.requests.cpu | string | `"20m"` | CPU resource request for the Backstage container |
| resources.requests.memory | string | `"250Mi"` | Memory resource request for the Backstage container |
| resources.limits | object | `{"cpu":"500m","memory":"600Mi"}` | CPU and memory resource limits |
| resources.limits.cpu | string | `"500m"` | CPU resource limit for the Backstage container |
| resources.limits.memory | string | `"600Mi"` | Memory resource limit for the Backstage container |
| authSessionSecret | string | `""` | Secret used for signing authentication sessions (exposed as AUTH_SESSION_SECRET env var) |
| circleci | object | `{"apiToken":""}` | CircleCI integration settings |
| circleci.apiToken | string | `""` | CircleCI API token for pipeline integration (exposed as CIRCLECI_API_TOKEN env var) |
| common | object | `{}` | Bitnami common library chart settings (subchart dependency) |
| dexAuthCredentials | object | `{}` | Dex authentication provider credentials, keyed by provider name. Each entry generates AUTH_DEX_<NAME>_CLIENT_ID and AUTH_DEX_<NAME>_CLIENT_SECRET env vars |
| githubAuthCredentials | object | `{"clientID":"","clientSecret":""}` | GitHub OAuth credentials for user authentication |
| githubAuthCredentials.clientID | string | `""` | GitHub OAuth App client ID (exposed as GITHUB_OAUTH_CLIENT_ID env var) |
| githubAuthCredentials.clientSecret | string | `""` | GitHub OAuth App client secret (exposed as GITHUB_OAUTH_CLIENT_SECRET env var) |
| githubAppCredentials | object | `{"appId":0,"clientId":"","clientSecret":"","privateKey":"","webhookSecret":"","webhookUrl":""}` | GitHub App credentials for repository access and webhooks |
| githubAppCredentials.appId | int | `0` | GitHub App ID |
| githubAppCredentials.webhookUrl | string | `""` | GitHub App webhook URL |
| githubAppCredentials.clientId | string | `""` | GitHub App OAuth client ID |
| githubAppCredentials.clientSecret | string | `""` | GitHub App OAuth client secret |
| githubAppCredentials.webhookSecret | string | `""` | GitHub App webhook secret |
| githubAppCredentials.privateKey | string | `""` | GitHub App private key (PEM format) |
| github | object | `{"publicReadToken":""}` | GitHub integration settings (PAT used as fallback by catalog processors when the GitHub App lacks access to a repository) |
| github.publicReadToken | string | `""` | GitHub personal access token with public read access (exposed as GITHUB_PUBLIC_READ_TOKEN env var) |
| grafana | object | `{"apiToken":""}` | Grafana integration settings |
| grafana.apiToken | string | `""` | Grafana API token for dashboard integration (exposed as GRAFANA_TOKEN env var) |
| sentry | object | `{"app":{"dsn":""},"backend":{"dsn":""},"reportURI":""}` | Sentry error tracking settings |
| sentry.app | object | `{"dsn":""}` | Sentry settings for the frontend application |
| sentry.app.dsn | string | `""` | Sentry DSN for the frontend app (exposed as SENTRY_DSN_APP env var) |
| sentry.backend | object | `{"dsn":""}` | Sentry settings for the backend service |
| sentry.backend.dsn | string | `""` | Sentry DSN for the backend service (exposed as SENTRY_DSN_BACKEND env var) |
| sentry.reportURI | string | `""` | Sentry CSP report URI (exposed as SENTRY_REPORT_URI env var) |
| telemetrydeck | object | `{"salt":""}` | TelemetryDeck analytics settings |
| telemetrydeck.salt | string | `""` | TelemetryDeck salt for hashing user identifiers (exposed as TELEMETRYDECK_SALT env var). Public by design, not a credential; see the note in templates/secrets.yaml. |
| aws | object | `{"accessKeyID":"","secretAccessKey":""}` | AWS credentials for S3 and other AWS service integrations |
| aws.accessKeyID | string | `""` | AWS access key ID (exposed as AWS_ACCESS_KEY_ID env var) |
| aws.secretAccessKey | string | `""` | AWS secret access key (exposed as AWS_SECRET_ACCESS_KEY env var) |
| externalAccess | object | `{"mcpToken":""}` | External access settings for programmatic API access |
| externalAccess.mcpToken | string | `""` | Bearer token for MCP (Model Context Protocol) external access (exposed as EXTERNAL_ACCESS_MCP_TOKEN env var) |
| anthropic | object | `{"apiKey":""}` | Anthropic AI provider settings |
| anthropic.apiKey | string | `""` | Anthropic API key for AI chat features (exposed as ANTHROPIC_API_KEY env var) |
| openai | object | `{"apiKey":""}` | OpenAI provider settings |
| openai.apiKey | string | `""` | OpenAI API key for AI chat features (exposed as OPENAI_API_KEY env var) |
| google | object | `{"credentialsJson":"","location":"","project":""}` | Google Vertex AI provider settings for AI chat (used when aiChat.model is a gemini-* model) |
| google.project | string | `""` | GCP project ID for Vertex AI (exposed as GOOGLE_CLOUD_PROJECT env var) |
| google.location | string | `""` | Vertex AI region, e.g. europe-west1 (exposed as GOOGLE_CLOUD_LOCATION env var) |
| google.credentialsJson | string | `""` | Service-account JSON content for Vertex AI authentication. When set, mounted as a file at /app/google/credentials.json (SOPS-encrypted in gitops). google-auth-library uses it to mint and auto-refresh short-lived OAuth2 tokens |
| pagerduty | object | `{"apiToken":""}` | PagerDuty integration settings |
| pagerduty.apiToken | string | `""` | PagerDuty API token for incident management integration (exposed as PAGERDUTY_TOKEN env var) |
| sharedConfig | object | `{}` | Shared configuration that generates a ConfigMap. Can be referenced in the main app configuration with $include keyword |
| nodeSelector | object | `{}` | Node selector labels to constrain pod scheduling to specific nodes |
| strategy | object | `{}` | Deployment update strategy. When empty, the Kubernetes default (RollingUpdate) is used. Set to `{type: Recreate}` when backing the pod with a ReadWriteOnce PVC (e.g. file-backed SQLite) so upgrades don't deadlock on the volume. |
| networkPolicy | object | `{"enabled":true,"flavor":"cilium"}` | Network policy settings |
| networkPolicy.enabled | bool | `true` | Render the network policies the chart ships. Turn this off on a cluster whose policy flavor the chart does not render. |
| networkPolicy.flavor | string | `"cilium"` | Policy flavor to render. The `kubernetes` flavor is not an exact equivalent of the `cilium` one: it has no `world` or `kube-apiserver` entity, so the egress leg that carries object storage and Kubernetes API traffic is `0.0.0.0/0` on 443 and 6443. Widen that leg in the template if the cluster reaches an object store on another port. |
| database | object | `{"engine":"sqlite","postgresql":{"affinity":{},"clusterNameSuffix":"cnpg","image":"giantswarm/postgresql-cnpg:18.0@sha256:424fc22287b7bf49e9eb87f6180e5489d0026014b1e610a4e429599d96cadb4d","imagePullSecrets":[],"instances":2,"operatorNamespace":"cnpg-system","storageSize":"5Gi"}}` | Database configuration |
| database.engine | string | `"sqlite"` | Database engine to use |
| database.postgresql | object | `{"affinity":{},"clusterNameSuffix":"cnpg","image":"giantswarm/postgresql-cnpg:18.0@sha256:424fc22287b7bf49e9eb87f6180e5489d0026014b1e610a4e429599d96cadb4d","imagePullSecrets":[],"instances":2,"operatorNamespace":"cnpg-system","storageSize":"5Gi"}` | Settings for the PostgreSQL database (only used when engine is "postgresql") |
| database.postgresql.clusterNameSuffix | string | `"cnpg"` | Suffix appended to the chart name to form the CNPG cluster resource name |
| database.postgresql.instances | int | `2` | Number of PostgreSQL instances in the CNPG cluster |
| database.postgresql.storageSize | string | `"5Gi"` | Persistent volume size for the PostgreSQL CNPG cluster |
| database.postgresql.operatorNamespace | string | `"cnpg-system"` | Namespace the CloudNativePG operator runs in. The network policy admits it on the instance status port, so the operator can extract instance status and start replica creation. |
| database.postgresql.image | string | `"giantswarm/postgresql-cnpg:18.0@sha256:424fc22287b7bf49e9eb87f6180e5489d0026014b1e610a4e429599d96cadb4d"` | PostgreSQL container image for the CNPG cluster (registry.domain is prepended). The image is published for linux/amd64 and linux/arm64; the digest must name the index, not one architecture's manifest, or the kubelet pulls the wrong architecture and the container exits with `exec format error`. |
| database.postgresql.imagePullSecrets | list | `[]` | Pull secrets for the CNPG cluster images, as a list of `{name: <secret>}`. The bootstrap init container runs the operator image, so a private mirror needs an entry here. |
| database.postgresql.affinity | object | `{}` | Placement for the CNPG instance pods. This is CloudNativePG's own `AffinityConfiguration`, not a core Kubernetes `Affinity`: the keys are `enablePodAntiAffinity`, `topologyKey`, `podAntiAffinityType`, `nodeSelector`, `tolerations`, `nodeAffinity`, `additionalPodAffinity` and `additionalPodAntiAffinity`. |
| branding | object | `{"assetsPath":"/app/branding-assets","enabled":false,"volume":{"configMap":{}}}` | Custom branding/UI asset settings (logos and favicons served by the branding backend plugin) |
| branding.enabled | bool | `false` | Enable serving custom branding assets (logos) from a mounted volume |
| branding.assetsPath | string | `"/app/branding-assets"` | Filesystem path inside the container where branding assets are mounted |
| branding.volume | object | `{"configMap":{}}` | Volume source for the branding assets. Currently only the `configMap` source is supported; the volume `name` is supplied by the chart. |
| branding.volume.configMap | object | `{}` | ConfigMap volume source. At minimum, set `.name` to the name of the ConfigMap holding the assets |
| backstage | object | `{"appConfig":{},"args":[],"command":["node","packages/backend"],"extraAppConfig":[],"extraEnvVars":[],"extraEnvVarsCM":[],"extraEnvVarsSecrets":[],"extraVolumeMounts":[],"extraVolumes":[],"initContainers":[]}` | Backstage application parameters |
| backstage.command | list | `["node","packages/backend"]` | Container command to start the Backstage backend |
| backstage.args | list | `[]` | Additional command arguments passed to the Backstage container |
| backstage.extraAppConfig | list | `[]` | Extra app configuration files to inline into command arguments, each referencing a ConfigMap |
| backstage.appConfig | object | `{}` | Inline Backstage app configuration that generates a ConfigMap automatically. Do not use for sensitive data |
| backstage.extraEnvVars | list | `[]` | Extra environment variables for the Backstage container |
| backstage.extraEnvVarsCM | list | `[]` | Names of existing ConfigMaps to mount as envFrom sources in the Backstage container |
| backstage.extraEnvVarsSecrets | list | `[]` | Names of existing Secrets to mount as envFrom sources in the Backstage container |
| backstage.extraVolumeMounts | list | `[]` | Additional volume mounts for the Backstage container |
| backstage.extraVolumes | list | `[]` | Additional volumes for the Backstage pod |
| backstage.initContainers | list | `[]` | Init containers to run before the Backstage container starts. Common use: `chown` a freshly provisioned PVC mount so the non-root Backstage user can write to it. |
| ingress | object | `{"annotations":{"cert-manager.io/cluster-issuer":"letsencrypt-giantswarm","kubernetes.io/tls-acme":"true","nginx.ingress.kubernetes.io/force-ssl-redirect":"true"},"className":"nginx","enabled":true,"hostnames":["default-hostname"]}` | Traditional Ingress configuration |
| ingress.enabled | bool | `true` | Enable the Kubernetes Ingress resource for external HTTP access |
| ingress.className | string | `"nginx"` | Ingress class name |
| ingress.annotations | object | `{"cert-manager.io/cluster-issuer":"letsencrypt-giantswarm","kubernetes.io/tls-acme":"true","nginx.ingress.kubernetes.io/force-ssl-redirect":"true"}` | Annotations applied to the Ingress resource |
| ingress.hostnames | list | `["default-hostname"]` | Hostnames for the Ingress rules and TLS configuration |
| route | object | `{"additionalRules":[],"annotations":{},"backendTrafficPolicy":{"annotations":{},"enabled":false,"labels":{},"spec":{}},"enabled":false,"filters":[],"hostnames":[],"kind":"HTTPRoute","labels":{},"matches":[{"path":{"type":"PathPrefix","value":"/"}}],"name":"","parentRefs":[],"securityPolicy":{"annotations":{},"authorization":{},"basicAuth":{},"cors":{},"enabled":false,"extAuth":{},"jwt":{},"labels":{},"oidc":{}}}` | Gateway API route configuration |
| route.enabled | bool | `false` | Enable the Gateway API HTTPRoute resource |
| route.kind | string | `"HTTPRoute"` | Route resource kind |
| route.name | string | `""` | Route name (defaults to .Values.name) |
| route.annotations | object | `{}` | Annotations applied to the route resource |
| route.labels | object | `{}` | Labels applied to the route resource |
| route.hostnames | list | `[]` | Hostnames for the route (supports Go templating) |
| route.parentRefs | list | `[]` | Parent Gateway references that this route attaches to |
| route.matches | list | `[{"path":{"type":"PathPrefix","value":"/"}}]` | Path matching rules for the route |
| route.filters | list | `[]` | Request/Response filters applied to the route |
| route.additionalRules | list | `[]` | Additional custom routing rules |
| route.securityPolicy | object | `{"annotations":{},"authorization":{},"basicAuth":{},"cors":{},"enabled":false,"extAuth":{},"jwt":{},"labels":{},"oidc":{}}` | Envoy Gateway SecurityPolicy configuration (gateway.envoyproxy.io/v1alpha1) |
| route.securityPolicy.enabled | bool | `false` | Enable the SecurityPolicy resource |
| route.securityPolicy.labels | object | `{}` | Labels applied to the SecurityPolicy resource |
| route.securityPolicy.annotations | object | `{}` | Annotations applied to the SecurityPolicy resource |
| route.securityPolicy.basicAuth | object | `{}` | Basic authentication configuration (reference to htpasswd secret) |
| route.securityPolicy.cors | object | `{}` | CORS (Cross-Origin Resource Sharing) policy configuration |
| route.securityPolicy.jwt | object | `{}` | JWT token validation configuration |
| route.securityPolicy.oidc | object | `{}` | OIDC authentication provider configuration |
| route.securityPolicy.extAuth | object | `{}` | External authorization service configuration |
| route.securityPolicy.authorization | object | `{}` | Authorization rules for request-level access control |
| route.backendTrafficPolicy | object | `{"annotations":{},"enabled":false,"labels":{},"spec":{}}` | Envoy Gateway BackendTrafficPolicy configuration (gateway.envoyproxy.io/v1alpha1) |
| route.backendTrafficPolicy.enabled | bool | `false` | Enable the BackendTrafficPolicy resource |
| route.backendTrafficPolicy.labels | object | `{}` | Labels applied to the BackendTrafficPolicy resource |
| route.backendTrafficPolicy.annotations | object | `{}` | Annotations applied to the BackendTrafficPolicy resource |
| route.backendTrafficPolicy.spec | object | `{}` | BackendTrafficPolicy spec passthrough (timeout, retry, circuitBreaker, etc.); targetRefs is injected automatically |
| ociRegistryCredentials | object | `{}` | Private OCI registry credentials, keyed by registry name. Each entry generates OCI_REGISTRY_<NAME>_USERNAME and OCI_REGISTRY_<NAME>_PASSWORD env vars. Registry hosts are configured in backstage.appConfig |
| pluginKeys | list | `[]` | Plugin signing key pairs, each mounted as files under /app/plugin-keys/<keyId>/ |
