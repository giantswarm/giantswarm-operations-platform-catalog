{{- define "support-portal-keycloak.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "support-portal-keycloak.fullname" -}}
{{- if contains .Chart.Name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "support-portal-keycloak.selectorLabels" -}}
app.kubernetes.io/name: {{ include "support-portal-keycloak.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "support-portal-keycloak.labels" -}}
{{ include "support-portal-keycloak.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
application.giantswarm.io/team: {{ index .Chart.Annotations "application.giantswarm.io/team" | quote }}
{{- end -}}

{{- define "support-portal-keycloak.image" -}}
{{ .Values.image.registry }}/{{ .Values.image.name }}:{{ .Values.image.tag | default .Chart.AppVersion }}{{ with .Values.image.digest }}@{{ . }}{{ end }}
{{- end -}}

{{/* Shared with the parent chart through global values. */}}
{{- define "support-portal-keycloak.hostname" -}}
{{- required "global.keycloak.hostname is required" .Values.global.keycloak.hostname -}}
{{- end -}}

{{- define "support-portal-keycloak.realm" -}}
{{- .Values.global.keycloak.realm | default "support" -}}
{{- end -}}

{{- define "support-portal-keycloak.portalURL" -}}
{{- printf "https://%s" (required "global.portalHostname is required" .Values.global.portalHostname) -}}
{{- end -}}

{{- define "support-portal-keycloak.existingSecret" -}}
{{- with .Values.global.existingSecrets }}{{ .keycloak | default "" }}{{ end -}}
{{- end -}}

{{- define "support-portal-keycloak.secretName" -}}
{{- include "support-portal-keycloak.existingSecret" . | default (include "support-portal-keycloak.fullname" .) -}}
{{- end -}}

{{/* Name of the Zalando postgresql cluster, which is also its Service. */}}
{{- define "support-portal-keycloak.dbCluster" -}}
{{- printf "%s-db" (include "support-portal-keycloak.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "support-portal-keycloak.dbHost" -}}
{{- if .Values.database.zalando.enabled -}}
{{- include "support-portal-keycloak.dbCluster" . -}}
{{- else -}}
{{- required "database.host is required without database.zalando.enabled" .Values.database.host -}}
{{- end -}}
{{- end -}}

{{/* The operator writes the owner's credentials into this Secret
(secret_name_template; underscores in the user name become dashes). */}}
{{- define "support-portal-keycloak.dbSecret" -}}
{{- if .Values.database.zalando.enabled -}}
{{- printf "%s.%s.credentials.postgresql.acid.zalan.do" (.Values.database.user | replace "_" "-") (include "support-portal-keycloak.dbCluster" .) -}}
{{- else -}}
{{- required "database.existingSecret is required without database.zalando.enabled" .Values.database.existingSecret -}}
{{- end -}}
{{- end -}}

{{/* Realm parts, as JSON. */}}
{{- define "support-portal-keycloak.smtpServer" -}}
{{- $s := .Values.email.smtp -}}
{{- if .Values.email.enabled -}}
{{- if not $s.host }}{{ fail "email.smtp.host is required with email.enabled" }}{{ end -}}
{{- $out := dict "host" $s.host "port" (toString $s.port) "from" $s.from "fromDisplayName" $s.fromDisplayName "starttls" (toString $s.starttls) "ssl" (toString $s.ssl) "auth" (toString $s.auth) -}}
{{- if $s.auth -}}
{{- $_ := set $out "user" $s.user -}}
{{- $_ := set $out "password" "${SMTP_PASSWORD}" -}}
{{- end -}}
{{- toJson $out -}}
{{- else -}}
{}
{{- end -}}
{{- end -}}

{{/* Alias of the staff identity provider; the portal reads it as
STAFF_IDP_ALIAS from the same global value. */}}
{{- define "support-portal-keycloak.staffAlias" -}}
{{- .Values.global.keycloak.staffIdpAlias | default "github" -}}
{{- end -}}

{{/* GitHub sign-in for Giant Swarm staff. It grants nothing by itself: the
portal checks every login's GitHub org membership. Hidden on the login page;
the portal's staff sign-in sends users there with kc_idp_hint. */}}
{{- define "support-portal-keycloak.identityProviders" -}}
{{- $p := .Values.realm.githubLogin -}}
{{- if $p.enabled -}}
{{- $config := dict
  "clientId" "${GITHUB_LOGIN_CLIENT_ID}"
  "clientSecret" "${GITHUB_LOGIN_CLIENT_SECRET}"
  "defaultScope" "user:email"
  "syncMode" "FORCE"
  "hideOnLoginPage" "true"
-}}
{{- list (dict "alias" (include "support-portal-keycloak.staffAlias" .) "displayName" $p.displayName "providerId" "github" "enabled" true "hideOnLogin" true "trustEmail" false "storeToken" false "linkOnly" false "firstBrokerLoginFlowAlias" "no-linking-first-broker-login" "config" $config) | toJson -}}
{{- else -}}
[]
{{- end -}}
{{- end -}}

{{/* Stores the GitHub login (not the email) in the user attribute
githubLogin on every sign-in; the support-portal client puts it into the
github_login claim. The group mapper puts every GitHub sign-in into
/github-sign-ins, which grants nothing (the portal decides who is staff by
GitHub org membership) but keeps the account within the portal's admin
permissions, which reach only the members of groups. */}}
{{- define "support-portal-keycloak.identityProviderMappers" -}}
{{- if .Values.realm.githubLogin.enabled -}}
{{- $alias := include "support-portal-keycloak.staffAlias" . -}}
{{- list (dict "name" "github login" "identityProviderAlias" $alias "identityProviderMapper" "github-user-attribute-mapper" "config" (dict "jsonField" "login" "userAttribute" "githubLogin" "syncMode" "FORCE")) (dict "name" "github sign-ins group" "identityProviderAlias" $alias "identityProviderMapper" "hardcoded-group-idp-mapper" "config" (dict "group" "/github-sign-ins" "syncMode" "FORCE")) | toJson -}}
{{- else -}}
[]
{{- end -}}
{{- end -}}
