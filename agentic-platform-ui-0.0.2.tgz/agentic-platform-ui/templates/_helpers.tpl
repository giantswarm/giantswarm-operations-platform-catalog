{{- /*
Validate slug at render time. Fail fast with a clear message rather than producing
a broken manifest that surfaces an error later in Flux reconcile.
*/ -}}

{{- define "agentic-platform-ui.validate" -}}
{{- $slug := .Values.slug | default "" -}}
{{- if not (regexMatch "^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$" $slug) -}}
{{- fail (printf "values.slug %q does not match ^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$" $slug) -}}
{{- end -}}
{{- end -}}

{{- /*
The release name. The Helm release is named externally (by the fleet HelmRelease),
but we provide a deterministic resource name here so that all resources within a
release agree on what to call the workload.
*/ -}}
{{- define "agentic-platform-ui.fullname" -}}
{{- printf "prototype-%s" .Values.slug | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "agentic-platform-ui.labels" -}}
app.kubernetes.io/name: agentic-platform-ui
app.kubernetes.io/instance: {{ include "agentic-platform-ui.fullname" . }}
app.kubernetes.io/managed-by: helm
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
agentic-platform-ui/slug: {{ .Values.slug | quote }}
{{- end -}}

{{- define "agentic-platform-ui.selectorLabels" -}}
app.kubernetes.io/name: agentic-platform-ui
app.kubernetes.io/instance: {{ include "agentic-platform-ui.fullname" . }}
{{- end -}}

{{- /*
Image reference. Registry and repo are hardcoded so that a compromised fleet bot
cannot redirect the deployment to an arbitrary image.

The image tag is derived from `.Chart.Version`, which the CI pipeline stamps at
`helm package --version 0.0.0-branch-<slug>-<build-num>` time. The same build
publishes an image tagged `branch-<slug>-<build-num>` (no `0.0.0-` prefix on the
image side — registry tags aren't required to be semver, only the chart's). We
strip the prefix here so chart and image co-version without a separate
ConfigMap value or Flux ImagePolicy chasing two tag streams in lockstep.
*/ -}}
{{- define "agentic-platform-ui.image" -}}
gsociprivate.azurecr.io/giantswarm/agentic-platform-ui:{{ trimPrefix "0.0.0-" .Chart.Version }}
{{- end -}}
