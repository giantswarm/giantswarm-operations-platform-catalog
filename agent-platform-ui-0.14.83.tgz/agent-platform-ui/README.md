# agent-platform-ui

Per-branch deployment of the agent-platform-ui prototype.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| slug | string | `"unconfigured"` |  |
| auth.basicAuth.htpasswd | string | `""` |  |
| siteping.enabled | bool | `true` |  |
| siteping.publicBaseUrl | string | `"https://apui.operations.awsprod.gigantic.io"` |  |
| siteping.slackWebhookUrl | string | `""` |  |
| siteping.storage.size | string | `"1Gi"` |  |
