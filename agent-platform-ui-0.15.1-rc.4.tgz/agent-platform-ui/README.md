# agent-platform-ui

Per-branch deployment of the agent-platform-ui prototype.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| slug | string | `"unconfigured"` |  |
| auth.basicAuth.htpasswd | string | `""` |  |
| siteping.enabled | bool | `true` |  |
| siteping.publicBaseUrl | string | `"https://apui.operations.awsprod.gigantic.io"` |  |
| siteping.slackWebhookUrl | string | `""` |  |
| siteping.storage.size | string | `"1Gi"` |  |
| architecture | string | `""` | Target CPU architecture for the prototype and SitePing pods. Empty imposes no constraint. `arm64` pins the pods to arm64 nodes, adding both the `kubernetes.io/arch` node selector and the toleration for the `kubernetes.io/arch=arm64:NoSchedule` taint that Giant Swarm arm64 node pools carry. Both are required, so this single value sets both. Requires multi-arch container images; an amd64-only image will crash-loop with `exec format error` on an arm64 node. |
| nodeSelector | object | `{}` | Node selector for both pods. Merged with `architecture`. Pinning to arm64 here rather than through `architecture` also adds the arm64 taint toleration, so either route is safe. A value that contradicts `architecture` fails the render. |
| tolerations | list | `[]` | Tolerations for both pods. Merged with the toleration that `architecture: arm64` adds. |
