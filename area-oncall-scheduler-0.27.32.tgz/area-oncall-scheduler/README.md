# area-oncall-scheduler

A Helm chart for area-oncall-scheduler

**Homepage:** <https://github.com/giantswarm/area-oncall-scheduler>

## Source Code

* <https://github.com/giantswarm/area-oncall-scheduler>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| image.name | string | `"giantswarm/area-oncall-scheduler"` |  |
| image.tag | string | `""` |  |
| image.pullSecretName | string | `"area-oncall-scheduler-pull-secret"` |  |
| Installation.V1.Registry.Domain | string | `"gsociprivate.azurecr.io"` |  |
| BackoffLimit | int | `6` |  |
| SuspendAll | bool | `false` |  |
| Cronjobs[0].Schedule | string | `"40 15 15 * *"` |  |
| Cronjobs[0].StartDateCmd | string | `"date -d \"$(date +%Y%m01) +1 month\" +%Y-%m-%d"` |  |
| Cronjobs[0].EndDateCmd | string | `"date -d \"$(date +%Y%m15) +1 month\" +%Y-%m-%d"` |  |
| Cronjobs[0].Suspend | bool | `false` |  |
| Cronjobs[1].Schedule | string | `"40 15 1 * *"` |  |
| Cronjobs[1].StartDateCmd | string | `"date -d \"$(date +%Y%m16) +1 month\" +%Y-%m-%d"` |  |
| Cronjobs[1].EndDateCmd | string | `"date -d \"$(date +%Y%m01) +2 month -1 day\" +%Y-%m-%d"` |  |
| Cronjobs[1].Suspend | bool | `false` |  |
| Flags[0] | string | `"--help"` |  |
| Secrets[0].name | string | `"google-calendar-service-account"` |  |
| Secrets[0].data[0].key | string | `"service-account.json"` |  |
| Secrets[0].data[0].value | string | `"{\n  \"type\": \"service_account\",\n  \"project_id\": \"example-project-id\",\n  ...\n}\n"` |  |
| Secrets[1].name | string | `"personio-credentials"` |  |
| Secrets[1].data[0].key | string | `"personio-credentials.json"` |  |
| Secrets[1].data[0].value | string | `"{\n  \"clientId\": \"CLIENT_ID\",\n  \"clientSecret\": \"CLIENT_SECRET\"\n}\n"` |  |
| Secrets[2].name | string | `"area-oncall-scheduler-pull-secret"` |  |
| Secrets[2].data[0].key | string | `".dockerconfigjson"` |  |
| Secrets[2].data[0].value | string | `"{\n  \"auths\": {\n    \"ghcr.io\": {\n      \"auth\": \"YmxhYmxhOmJsYWJsYQo=\"\n    }\n  }\n}\n"` |  |
| Volumes[0].name | string | `"google-calendar-service-account"` |  |
| Volumes[0].secret.secretName | string | `"google-calendar-service-account"` |  |
| Volumes[0].secret.items[0].key | string | `"service-account.json"` |  |
| Volumes[0].secret.items[0].path | string | `"service-account.json"` |  |
| Volumes[1].name | string | `"personio-credentials"` |  |
| Volumes[1].secret.secretName | string | `"personio-credentials"` |  |
| Volumes[1].secret.items[0].key | string | `"personio-credentials.json"` |  |
| Volumes[1].secret.items[0].path | string | `"personio-credentials.json"` |  |
| VolumeMounts[0].name | string | `"google-calendar-service-account"` |  |
| VolumeMounts[0].mountPath | string | `"/service-account.json"` |  |
| VolumeMounts[0].subPath | string | `"service-account.json"` |  |
| VolumeMounts[1].name | string | `"personio-credentials"` |  |
| VolumeMounts[1].mountPath | string | `"/personio-credentials.json"` |  |
| VolumeMounts[1].subPath | string | `"personio-credentials.json"` |  |
| Resources.requests.cpu | string | `"200m"` |  |
| Resources.requests.memory | string | `"32Mi"` |  |
| Resources.requests.ephemeral-storage | string | `"32Mi"` | Ephemeral storage request. Bounds the `temp` emptyDir at `/tmp`, which exists only to give the read-only root filesystem a writable path. |
| Resources.limits.cpu | string | `"500m"` |  |
| Resources.limits.memory | string | `"64Mi"` |  |
| Resources.limits.ephemeral-storage | string | `"128Mi"` | Ephemeral storage limit. Exceeding it evicts the job mid-run. The job writes to `/tmp` only when a `Flags` entry points the `output` flag there, so this is headroom rather than a measured figure. |
| global.podSecurityStandards.enforced | bool | `false` |  |
| baseDomain | string | `""` |  |
| bootstrapMode | object | `{}` |  |
| chartOperator | object | `{}` |  |
| ciliumNetworkPolicy | object | `{}` |  |
| cluster | object | `{}` |  |
| clusterCA | string | `""` |  |
| clusterCIDR | string | `""` |  |
| clusterDNSIP | string | `""` |  |
| clusterID | string | `""` |  |
| gcpProject | string | `""` |  |
| provider | string | `""` |  |
| subscriptionID | string | `""` |  |
